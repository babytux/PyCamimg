LogName = "PyCamimg"
gettextName = "pycamimg"